package bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Validate{
	public int GetNum() {
		int num;
        while (true) {
            try {
            	Scanner sc = new Scanner(System.in);
                num = sc.nextInt();
                return num;
            } catch (InputMismatchException ex) {
                System.out.println("No ha insertado un numero, error" + ex);
            }
        }
	}
	
	public static Date GetDate(){
		String FechaStr;
		SimpleDateFormat Formato = new SimpleDateFormat("dd/mm/yyyy");
        while (true) {
            try {
            	Scanner sc = new Scanner(System.in);
            	FechaStr = sc.next();
        		Date Fecha = Formato.parse(FechaStr);
                return Fecha;
            } catch (ParseException ex) {
                System.out.println("No ha insertado una fecha correcta, error" + ex);
            }
        }
	}
}