package Utility;

import java.io.File;

public class FileManagement {
	
	public FileManagement() {}
	
	public static void DeleteFile(String fileName) {
		String root = System.getProperty("user.dir");
		File delFile = new File(root+"//src//Database//"+fileName);	
		if (delFile.exists()) {
			delFile.delete();
		}
	}
	
	public static String Root() {
		return System.getProperty("user.dir")+"//src//Database//";
	}

}

