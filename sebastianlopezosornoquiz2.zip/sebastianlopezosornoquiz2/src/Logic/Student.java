package Logic;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import Bean.Person;
import Utility.FileManagement;

public class Student extends Person {
	private ArrayList<Person> Estudiantes;
	public Student(Person Estudiante) {
		
	}
	
	public void WriteData() {
		ArrayList<Person> ListPersons = ListerPerson();
		Person[] Persons = new Person[ListPersons.size()];
		for(int i=0; i < ListPersons.size(); i++)
		{

			Persons[i] = new Person();
			Persons[i].setId(ListPersons.get(i).getId());
			Persons[i].setName(ListPersons.get(i).getName());
			Persons[i].setLastname(ListPersons.get(i).getLastname());
			Persons[i].setDateBirth(ListPersons.get(i).getDateBirth());
			Persons[i].setType(ListPersons.get(i).getType());

		}
		try
		{
		FileOutputStream FilePath = new FileOutputStream(FileManagement.Root()+"DataSerialized.txt");
		ObjectOutputStream archivo_salida = new ObjectOutputStream(FilePath);
		archivo_salida.writeObject(Persons);
		archivo_salida.close();
		}catch(Exception e)
		{

		System.out.println("Se ha generado un error al acceder al archivo:" + e);

		}
	}
	
	private ArrayList<Person> ListerPerson() {
		
		return null;
	}

	public static void ReadData() {
		try
		{
			FileInputStream FilePath = new FileInputStream(FileManagement.Root()+"DataSerialized.txt");
			ObjectInputStream ObjInpt = new ObjectInputStream(FilePath);
			Person[] DataRead = (Person[]) ObjInpt.readObject();
			ObjInpt.close();
			String line = "";
			ArrayList<Person> data = new ArrayList<Person>();
			for(int i=0; i < DataRead.length;i++)
			{
	
			data.add(DataRead[i]) ;
			
			}
			Show(data);
		}catch(Exception e) {
			System.out.println("Se ha generado un error al acceder al archivo: "+e);
		}
	}
	
	public static void Show(ArrayList<Person> data) {
		for(Person P: data)
		{
			String line = P.getId() + " - " + P.getName()+" "+P.getLastname()+ " "+P.getDateBirth() ;
			System.out.println(line);

		}
	}
	
}
